PLE with Keras
--------------
wip
